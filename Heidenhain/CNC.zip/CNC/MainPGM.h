0  BEGIN PGM MainPGM MM 
1  ;--------------------------------
2  LBL 1
3  FN 18: SYSREAD Q900 = ID2000 NR20 IDX20
4  FN 10: IF +Q900 NE +1 GOTO LBL 2
5  CALL PGM Peca1.h
6  ;--------------------------------
7  LBL 2
8  FN 18: SYSREAD Q900 = ID2000 NR20 IDX21
9  FN 10: IF +Q900 NE +1 GOTO LBL 3
10 CALL PGM Peca2.h
11 ;--------------------------------
12 LBL 3
13 FN 18: SYSREAD Q900 = ID2000 NR20 IDX22
14 FN 10: IF +Q900 NE +1 GOTO LBL 4
15 CALL PGM Peca3.h
16 ;--------------------------------
17 LBL 4
18 CYCL DEF 9.0 DWELL TIME
19 CYCL DEF 9.1 DWELL5
20 FN 9: IF +1 EQU +1 GOTO LBL 1
21 END PGM MainPGM MM 
