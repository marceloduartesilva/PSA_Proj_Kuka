var rowLength =5;
var alphabet = new Array(26);

alphabet[0]="A";
alphabet[1]="B";
alphabet[2]="C";
alphabet[3]="D";
alphabet[4]="E";
alphabet[5]="F";
alphabet[6]="G";
alphabet[7]="H";
alphabet[8]="I";
alphabet[9]="J";

alphabet[10]="K";
alphabet[11]="L";
alphabet[12]="M";
alphabet[13]="N";
alphabet[14]="O";
alphabet[15]="P";
alphabet[16]="Q";
alphabet[17]="R";
alphabet[18]="S";

alphabet[19]="T";
alphabet[20]="U";
alphabet[21]="V";
alphabet[22]="W";
alphabet[23]="X";
alphabet[24]="Y";
alphabet[25]="Z";

/**
 * Global object for keyboards number buttons. It's possible to change
 * Order of keyboards button from this file.
 */
var numbers = new Array(37);

numbers[0]= "1";
numbers[1]= "2";
numbers[2]= "3";
numbers[3]= "4";
numbers[4]= "5";
numbers[5]= "6";
numbers[6]= "7";
numbers[7]= "8";
numbers[8]= "9";
numbers[9]= "0";

numbers[10]= "(";
numbers[11]= ")";
numbers[12] = "\u20AC";
numbers[13]= "&";
numbers[14]= "@";
numbers[15]= "$";
numbers[16]= "%";
numbers[17]= "+";
numbers[18]= "#";

numbers[19]= "!";
numbers[20]= ",";
numbers[21]= ".";
numbers[22]= ";";
numbers[23]= ":";
numbers[24]= "/";
numbers[25]= "_";
numbers[26]= "=";

numbers[27]= "^";
numbers[28]= "[";
numbers[29]= "]";
numbers[30]= "|";
numbers[31]= "*";
numbers[32]= "-";
numbers[33]= "\"";
numbers[34]= "<";
numbers[35]= ">";
numbers[36]= "\\"
